from ndStepwise import run_single_datasets


run_single_datasets.main("car_evaluation", "logisticRegression")