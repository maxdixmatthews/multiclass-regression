# multiclass-regression

Maxwell Dix-Matthews honours project in multicategory regression